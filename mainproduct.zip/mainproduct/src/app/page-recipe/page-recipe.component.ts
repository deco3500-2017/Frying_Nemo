import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-recipe',
  templateUrl: './page-recipe.component.html',
  styleUrls: ['./page-recipe.component.scss']
})
export class PageRecipeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
