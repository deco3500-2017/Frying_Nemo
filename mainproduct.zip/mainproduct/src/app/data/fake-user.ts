import { user } from '../classes/user';

export const allUsers: user[] = [
    {
        name: 'Woody Sins',
        gender: 'Male',
        age: 11,
        weight: 31,
        height: 120
    }
]
