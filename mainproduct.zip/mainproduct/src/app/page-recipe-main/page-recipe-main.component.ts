import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-recipe-main',
  templateUrl: './page-recipe-main.component.html',
  styleUrls: ['./page-recipe-main.component.scss']
})
export class PageRecipeMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
