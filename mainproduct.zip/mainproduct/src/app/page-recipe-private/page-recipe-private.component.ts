import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-recipe-private',
  templateUrl: './page-recipe-private.component.html',
  styleUrls: ['./page-recipe-private.component.scss']
})
export class PageRecipePrivateComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }

}
