import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-lunch',
  templateUrl: './page-lunch.component.html',
  styleUrls: ['./page-lunch.component.scss']
})
export class PageLunchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
