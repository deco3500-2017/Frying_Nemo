import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-library',
  templateUrl: './page-library.component.html',
  styleUrls: ['./page-library.component.scss']
})
export class PageLibraryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
